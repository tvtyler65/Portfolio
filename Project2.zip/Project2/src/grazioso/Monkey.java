package grazioso;


public class Monkey extends RescueAnimal {
		//defining all variables
		public String name;
		public int tailLength;
		public int bodyLength;
		public int height;
		public String species;
		
		//constructor that takes input and sets monkey variables
		public Monkey(String name, int tailLength, int bodyLength, int height, String species) {
			setName(name);
			setTailLength(tailLength);
			setHeight(height);
			setBodyLength(bodyLength);
			setSpecies(species);
			
		}

		//getters and setters
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		public int getTailLength() {
			return tailLength;
		}

		public void setTailLength(int tailLength) {
			this.tailLength = tailLength;
		}

		public int getBodyLength() {
			return bodyLength;
		}

		public void setBodyLength(int bodyLength) {
			this.bodyLength = bodyLength;
		}

		public int getHeight() {
			return height;
		}

		public void setHeight(int height) {
			this.height = height;
		}

		public String getSpecies() {
			return species;
		}

		public void setSpecies(String species) {
			this.species = species;
		}
}
